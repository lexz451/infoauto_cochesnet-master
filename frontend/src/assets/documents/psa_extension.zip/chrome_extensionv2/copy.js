/**
 * Alta Cliente B2C
 * New account: B2C_PA
 * lead_client.client_type in (private, freelance)
 * 
 * Fields:
 * - Nombre - client_name
 * - Appelidos - client_surname
 * - Método de contacto preferido
 * - Móvil - client_phone
 * - Tlfn - input[name="client___desk_phone"]
 * - Email profesional - client_email
 * - Dirección - client_address1
 * - CP - client_postalcode
 * - Ciudad - client_location
 * - Provincia - client_province
 * - Dirección 2 - client_address2
 */


/**
* Alta Cliente B2B
* New account: B2B
* lead_client.client_type =company
* 
* Fields:
* - Nombre de la cuenta
* - CIF
* - Teléfono
* - Correo electrónico
* - Sector
* - CP facturación
* - Dirección facturación
* - Ciudad facturación
* - Provincia facturación
* - Complemento de dirección de facturación
*/

// Versión de la extensión para debug
console.log("Version: 1.6.1");

// var lead = {};
// console.log(chrome);

CUSTOMER_360_PSA_URL = "https://www.customer360psa.com/PSADealer/s/advanced-search?";
ALLOWED_DOMAIN = ["infoauto-backend", "cochesnet", "smartmotorlead", "sail.artificialintelligencelead"];
copy = function () {

	if (matchInArray(document.domain, ALLOWED_DOMAIN)) {
		var citroen_pive_element = document.getElementById('extra-button');
		var btn = document.createElement('button');

		btn.id = 'btn-confirm';
		btn.type = "button";
		btn.innerHTML = "Customer 360 PSA";

		btn.addEventListener("click", function (event) {
			event.preventDefault();


			var client_name = document.getElementById('client-name').value;
			var client_surname = document.getElementById('client-surname').value;
			var client_email = document.getElementById('client-email').value;
			var client_province = document.getElementById('client-province').value;
			var client_postalcode = document.getElementById('client-postal-code').value;
			var client_seller = document.getElementById('client-seller').textContent;
			var client_phone = document.getElementById("client-phone").getElementsByTagName("input")[0].value;
			var client_desk_phone = document.querySelector('input[name="client___desk_phone"]').value;
			var client_province = document.getElementById("client-province").getElementsByTagName("input")[0].value;
			var client_location = document.getElementById("client-location").getElementsByTagName("input")[0].value;
			var client_address1 = document.querySelector('input[name="client___address1"]').value;
			var client_address2 = document.querySelector('input[name="client___address2"]').value;
			var client_type = document.querySelector('select[name="client___client_type"]').value;
			var bussiness_name = document.querySelector('input[name="client___business_name"]').value;
			var bussiness_id = document.querySelector('input[name="client___identification"]').value;

			var data = {
				client_name,
				client_surname,
				client_phone,
				client_desk_phone,
				client_email,
				client_province,
				client_province,
				client_location,
				client_postalcode,
				client_seller,
				client_address1,
				client_address2,
				client_type,
				bussiness_name,
				bussiness_id,
			}


			console.log(data);
			console.log(CUSTOMER_360_PSA_URL + serialize(data));
			window.open(CUSTOMER_360_PSA_URL + serialize(data));

		});

		citroen_pive_element.innerHTML = "";
		citroen_pive_element.appendChild(btn);
	}
}



function matchInArray(string, expressions) {
	var len = expressions.length, i = 0;
	for (; i < len; i++) {
		if (string.match(expressions[i])) {
			return true;
		}
	}
	return false;
}

serialize = function (obj) {
	var str = [];
	for (var p in obj)
		if (obj.hasOwnProperty(p)) {
			str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
		}
	return str.join("&");
}

setTimeout(copy, 5000);

chrome.runtime.onMessage.addListener(
	function (request, sender, sendResponse) {
		// listen for messages sent from background.js
		if (request.message === 'change_tab_event') {
			setTimeout(copy, 5000);
		}
	}
);
/*
copyTasks = function() {
	document.querySelector("div[id*='task']");
	var aux = document.querySelector("div[id*='task'] .layout-row");

	// como coger el checkbox?

	var plannedDate = document.querySelector("div[id*='task'] .layout-row .planified_realization_date").innerText;
	var media = document.querySelector("div[id*='task'] .layout-row .media");
	var type = document.querySelector("div[id*='task'] .layout-row .type");
	var subType = document.querySelector("div[id*='task'] .layout-row .subtype");
	var description = document.querySelector("div[id*='task'] .layout-row .description");
	var completedDate = document.querySelector("div[id*='task'] .layout-row .realization_date");

	
};

setTimeout(copyTasks, 5000);
*/