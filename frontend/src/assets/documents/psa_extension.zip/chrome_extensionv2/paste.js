paste = function () {

	var paste_domain = new RegExp("customer360psa.com");

	if (paste_domain.test(document.domain) == true) {
		var client_name = getUrlParameter('client_name');
		var client_surname = getUrlParameter('client_surname');
		var client_phone = getUrlParameter('client_phone');
		var client_email = getUrlParameter('client_email');
		var client_desk_phone = getUrlParameter('client_desk_phone');
		var client_province = getUrlParameter('client_province');
		var client_location = getUrlParameter('client_location');
		var client_postal_code = getUrlParameter('client_postalcode');
		var client_seller = getUrlParameter('client_seller');
		var client_type = getUrlParameter('client_type');
		var bussiness_name = getUrlParameter('bussiness_name');
		var bussiness_id = getUrlParameter('bussiness_id');
		var bussiness_sector = getUrlParameter('bussiness_sector');
		var client_address1 = getUrlParameter('client_address1');
		var client_address2 = getUrlParameter('client_address2');


		var searchClientButton = document.querySelector('.search-form button.slds-button');

		var createClientButton = document.querySelector('button.slds-button[value="create"]');

		console.log("type:", client_type);

		var selectInput = document.querySelector('select[id="79:2;a"]');
		if (client_type == "private") {
			
			selectInput.value = "B2C";
			selectInput.dispatchEvent(new Event('change'));
			searchClientButton.click();

			setTimeout(function () {
				createClientButton.click();
			}, 500);

			setTimeout(function () {
				var modalChild = document.querySelector(".slds-section__content")
				var idSuffix = modalChild.id.split(":")[1];

				
				document.getElementById("123:" + idSuffix).value = client_name;
				document.getElementById("123:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("133:" + idSuffix).value = client_surname;
				document.getElementById("133:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("150:" + idSuffix).value = client_desk_phone;
				document.getElementById("150:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("186:" + idSuffix).value = client_phone;
				document.getElementById("186:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("433:" + idSuffix).value = client_email;
				document.getElementById("433:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("546:" + idSuffix).value = client_address1;
				document.getElementById("546:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("658:" + idSuffix).value = client_address2;
				document.getElementById("658:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("525:" + idSuffix).value = client_province;
				document.getElementById("525:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("556:" + idSuffix).value = client_postal_code;
				document.getElementById("556:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("566:" + idSuffix).value = client_location;
				document.getElementById("566:" + idSuffix).dispatchEvent(new Event('change'));
				}, 3500);
		} else if(client_type == "company" || client_type == "freelance") {
			selectInput.value = "B2B";
			selectInput.dispatchEvent(new Event('change'));
			searchClientButton.click();

			setTimeout(function () {
				createClientButton.click();
			}, 500);

			setTimeout(function () {
				var modalChild = document.querySelector(".slds-section__content")
				var idSuffix = modalChild.id.split(":")[1];

				document.getElementById("11:" + idSuffix).value = bussiness_name;
				document.getElementById("11:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("123:" + idSuffix).value = bussiness_id;
				document.getElementById("123:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("153:" + idSuffix).value = client_phone;
				document.getElementById("153:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("199:" + idSuffix).value = client_email;
				document.getElementById("199:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("388:" + idSuffix).value = client_address1;
				document.getElementById("388:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("398:" + idSuffix).value = client_postal_code;
				document.getElementById("398:" + idSuffix).dispatchEvent(new Event('change'));				
				document.getElementById("408:" + idSuffix).value = client_location;
				document.getElementById("408:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("367:" + idSuffix).value = client_province;
				document.getElementById("367:" + idSuffix).dispatchEvent(new Event('change'));
				document.getElementById("500:" + idSuffix).value = client_address2;
				document.getElementById("500:" + idSuffix).dispatchEvent(new Event('change'));
			}, 3500);
		}



	}
}

getUrlParameter = function (name) {
	name = name.replace(/[\[]/, '\\[').replace(/[\]]/, '\\]');
	var regex = new RegExp('[\\?&]' + name + '=([^&#]*)');
	var results = regex.exec(location.search);
	return results === null ? '' : decodeURIComponent(results[1].replace(/\+/g, ' '));
};

findSeller = function (client_seller) {
	var seller_combo = document.getElementById("cli_CodVendeur");
	var i = 1;
	for (; i < seller_combo.length; i++) {
		console.log(seller_combo[i].text);
		console.log(seller_combo[i].value);
		if (similarity(client_seller, seller_combo[i].text) >= 0.80) {
			return seller_combo[i].value
		}

	}
}

similarity = function (s1, s2) {

	var longer = s1;
	var shorter = s2;

	if (s1.length < s2.length) {
		longer = s2;
		shorter = s1;
	}

	var longerLength = longer.length;

	if (longerLength == 0) {
		return 1.0;
	}

	return (longerLength - editDistance(longer, shorter)) / parseFloat(longerLength);
}

editDistance = function (s1, s2) {

	s1 = s1.toLowerCase();
	s2 = s2.toLowerCase();

	var costs = new Array();
	for (var i = 0; i <= s1.length; i++) {
		var lastValue = i;
		for (var j = 0; j <= s2.length; j++) {
			if (i == 0)
				costs[j] = j;
			else {
				if (j > 0) {
					var newValue = costs[j - 1];
					if (s1.charAt(i - 1) != s2.charAt(j - 1))
						newValue = Math.min(Math.min(newValue, lastValue),
							costs[j]) + 1;
					costs[j - 1] = lastValue;
					lastValue = newValue;
				}
			}
		}
		if (i > 0)
			costs[s2.length] = lastValue;
	}
	return costs[s2.length];
}

setTimeout(paste, 5000);
